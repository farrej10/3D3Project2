#include "routerFunctions.h"
#include <arpa/inet.h>
#include <errno.h>
#include <iostream>
#include <netinet/in.h>
#include <pthread.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <sys/socket.h>
#include <sys/types.h>
#include <thread>
#include <unistd.h>

#define max_threads 10

void* handleTable(void* id);

int main(int argc, char* argv[])
{

    char buf[1024];
    int opensocket;
    int sendcheck;
    int count = 0;
    if (argv[1][0] != 'H') {
        routerFunctions router;

        router.start_up(argv);

        opensocket = router.createsocket();

        router.findConnections();

        sendcheck = router.sendDV(opensocket);

        if (sendcheck == -1) {
            std::cerr << "Error sending DV";
        }

        sockaddr_in client; // Use to hold the client information (port / ip address)
        int clientLength = sizeof(client); // The size of the client information

        int pid = fork();
        if (pid < 0) {
            std::cerr << "fork failure" << std::endl;
            return 0;
        } else if (pid == 0) {
            sleep(15);
            while (true) {
                //cast

                router.areYouAlive(opensocket);
                sleep(5);
            }
        } else {
            while (router.stable == false) {
                memset(&client, 0, clientLength); // Clear the client structure
                memset(buf, 0, 1024); // Clear the receive buffer

                // Wait for message
                int bytesIn = recv(opensocket, buf, 1024, 0);
                if (bytesIn < 0)
                    return -2;

                // Display message and client info
                char clientIp[256]; // Create enough space to convert the address byte array
                memset(clientIp, 0, 256); // to string of characters

                // Convert from byte array to chars
                inet_ntop(AF_INET, &client.sin_addr, clientIp, 256);

                if (buf[0] == 'P') {

                    cout << "Sending Packet\n";
                    if (router.ID == buf[4]) {

                        cout << "Packet Recieved\n"
                             << "Source: A\n"
                             << "Destination: " << buf[4] << endl;
                        cout << "Payload: ";
                        string str(buf);
                        str = str.substr(6, string::npos);
                        cout << str << endl;

                    } else {
                        //std::cerr << "Packet was sent";

                        sendcheck = router.sendPacket(opensocket, buf);
                        if (sendcheck == -1) {
                            std::cerr << "Error sending Packet";
                        }
                    }

                }

                // N = ping
                else if (buf[0] == 'N') {
                    char letter = buf[2];
                    switch (letter) {
                    case 'A':
                        //reset time
                        router.timers[0] = clock();
                        break;
                    // start time
                    case 'B':
                        router.timers[1] = clock();
                        break;
                    case 'C':
                        router.timers[2] = clock();
                        break;
                    case 'D':
                        router.timers[3] = clock();
                        break;
                    case 'E':
                        router.timers[4] = clock();
                        break;
                    case 'F':
                        router.timers[5] = clock();
                        break;
                    }

                } else {

                    string str(buf);

                    router.add_entry(str);

                    if (router.printNew == 1 || count < 5) {

                        sendcheck = router.sendDV(opensocket);
                        if (sendcheck == -1) {
                            std::cerr << "Error sending DV";
                        }
                        count++;
                    }
                    router.printTable();
                }
            }
            double timeElapsed;
            for (unsigned int i = 0; i < router.peers.size(); i++) {

                switch (router.peers[i]) {
                case 'A':
                    timeElapsed = (clock() - router.timers[0]) / CLOCKS_PER_SEC;
                    if (timeElapsed > 5) {
						//cout << "Dead router";
                        router.RTentries[0] = "A,Z,ZZZZZ";
                        router.sendDV(opensocket);
                    }
                    break;
                case 'B':
                    timeElapsed = (clock() - router.timers[1]) / CLOCKS_PER_SEC;
                    if (timeElapsed > 5) {
                        router.RTentries[1] = "B,Z,ZZZZZ";
                        router.sendDV(opensocket);
                    }
                    break;
                case 'C':
                    timeElapsed = (clock() - router.timers[2]) / CLOCKS_PER_SEC;
                    if (timeElapsed > 5) {
                        router.RTentries[2] = "C,Z,ZZZZZ";
                        router.sendDV(opensocket);
                    }
                    break;
                case 'D':
                    timeElapsed = (clock() - router.timers[3]) / CLOCKS_PER_SEC;
                    if (timeElapsed > 5) {
                        router.RTentries[3] = "D,Z,ZZZZZ";
                        router.sendDV(opensocket);
                    }
                    break;
                case 'E':
                    timeElapsed = (clock() - router.timers[4]) / CLOCKS_PER_SEC;
                    if (timeElapsed > 5) {
                        router.RTentries[4] = "E,Z,ZZZZZ";
                        router.sendDV(opensocket);
                    }
                    break;
                case 'F':
                    timeElapsed = (clock() - router.timers[5]) / CLOCKS_PER_SEC;
                    if (timeElapsed > 5) {
                        router.RTentries[5] = "F,Z,ZZZZZ";
                        router.sendDV(opensocket);
                    }
                    break;
                }
            }

            close(opensocket);
        }

    }

    else { //H packet stuff

        string temp;
        temp = "P,A,D,";
        temp = temp + argv[2];
        std::cerr << temp;
        int opensocket = socket(AF_INET, SOCK_DGRAM, 0); //open socket

        if (opensocket == -1) {
            std::cerr << "Error opening socket." << std::endl;
            return -1;
        }

        sockaddr_in node;
        node.sin_family = AF_INET; // AF_INET = IPv4 addresses
        node.sin_port = htons(10000); // A port
        inet_pton(AF_INET, "127.0.0.1", &node.sin_addr); // Convert from string to byte array

        int sendOk = sendto(opensocket, temp.c_str(), temp.size() + 1, 0, (sockaddr*)&node, sizeof(node));
        if (sendOk == -1) {
            cout << "That didn't work! " << endl;
            return -1;
        }
    }

    return 0;
}
